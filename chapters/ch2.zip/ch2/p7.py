# minutes in a year
print('there are ',60 * 24 * 365,'minutes in a year')
