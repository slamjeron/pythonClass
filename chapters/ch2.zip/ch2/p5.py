mass = float (input('input the objects mass in kilograms:'))
velocity = float(input('input the objects velocity in meters'
                 ' per second: '))
print('this objects momentum energy is ', mass * velocity)
