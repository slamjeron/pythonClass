mass = float(input('input the objects mass in kilograms:'))
velocity = float(input('input the objects velocity in meters'
                 ' per second: '))
print('the objects kinetic energy is ', (mass * velocity**2)/2)
print('this objects momentum is ', mass * velocity)