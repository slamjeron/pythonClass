secondsInYear = 60 * 60 * 24 * 365
print('light will travel',secondsInYear * 3 * pow(10, 8),'miles in a year')
