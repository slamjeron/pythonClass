nautical = 60 * 90
kilometers = 10000
inkil=float(input('input kilometers to convert: '))
conv=nautical/kilometers
print(inkil,'kilometers is equal to ',inkil*conv)
